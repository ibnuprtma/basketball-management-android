<?php
include '../config/connection.php';

$id = addslashes(htmlentities($_POST['id']));
$name = addslashes(htmlentities($_POST['name']));
$position = addslashes(htmlentities($_POST['position']));
$number_jersey = addslashes(htmlentities($_POST['number_jersey']));
$address = addslashes(htmlentities($_POST['address']));

$update = "update players set name='$name', position='$position', number_jersey='$number_jersey', address='$address' where id='$id'";

$result = mysqli_query($conn, $update);

$response = array();
if($result){
    $response['status'] = "success";
    $response['code'] = 1;
    $response['message'] = "Berhasil Mengubah Data";
}else{
    $response['status'] = "failed";
    $response['code'] = 0;
    $response['message'] = "Gagal Mengubah Data";
}

echo json_encode($response);