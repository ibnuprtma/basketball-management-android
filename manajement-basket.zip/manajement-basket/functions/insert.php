<?php
include '../config/connection.php';

$name = addslashes(htmlentities($_POST['name']));
$position = addslashes(htmlentities($_POST['position']));
$number_jersey = addslashes(htmlentities($_POST['number_jersey']));
$address = addslashes(htmlentities($_POST['address']));
$images = addslashes(htmlentities($_POST['images']));

$insert = "insert into players(name,position,number_jersey,address,images) values('$name','$position','$number_jersey','$address','$images')";

$result = mysqli_query($conn, $insert);


$response = array();
if($result){
    $response['status'] = "success";
    $response['code'] = 1;
    $response['message'] = "Berhasil Menambah Data";
}else{
    $response['status'] = "failed";
    $response['code'] = 0;
    $response['message'] = "Gagal Menambah Data";
}

echo json_encode($response);