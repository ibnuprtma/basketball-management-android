<?php
include '../config/connection.php';

$query = "select * from players";
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) > 0){
    $response = array();
    $response['status'] = "success";
    $response['rows'] = mysqli_num_rows($result);
    $response['player'] = array();
    while ($row = mysqli_fetch_array($result)) {
        $player['id'] = $row['id'];
        $player['name'] = $row['name'];
        $player['position'] = $row['position'];
        $player['number_jersey'] = $row['number_jersey'];
        $player['address'] = $row['address'];
        $player['images'] = $row['images'];
        array_push($response['player'], $player);
    }
    
    echo json_encode($response);
}
