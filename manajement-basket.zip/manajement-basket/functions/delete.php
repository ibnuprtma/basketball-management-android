<?php
include '../config/connection.php';

$id = addslashes(htmlentities($_POST['id']));

$update = "delete from players where id='$id'";

$result = mysqli_query($conn, $update);

$response = array();
if($result){
    $response['status'] = "success";
    $response['code'] = 1;
    $response['message'] = "Berhasil Menghapus Data";
}else{
    $response['status'] = "failed";
    $response['code'] = 0;
    $response['message'] = "Gagal Menghapus Data";
}

echo json_encode($response);